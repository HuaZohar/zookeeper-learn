package com.alibaba.dubbo.common.extensionloader.ext9_empty;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public interface Ext9Empty {
    void empty();
}
