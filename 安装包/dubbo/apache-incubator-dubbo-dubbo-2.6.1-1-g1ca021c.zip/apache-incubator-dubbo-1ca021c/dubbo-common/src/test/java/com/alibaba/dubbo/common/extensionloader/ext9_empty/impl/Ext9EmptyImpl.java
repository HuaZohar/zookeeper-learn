package com.alibaba.dubbo.common.extensionloader.ext9_empty.impl;

import com.alibaba.dubbo.common.extensionloader.ext9_empty.Ext9Empty;

public class Ext9EmptyImpl implements Ext9Empty {
    @Override
    public void empty() {

    }
}
